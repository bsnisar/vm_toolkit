CREATE USER "smart-stub" WITH PASSWORD 'smart-stub';
CREATE DATABASE "smart-stub";
GRANT ALL PRIVILEGES ON DATABASE "smart-stub" to "smart-stub";
